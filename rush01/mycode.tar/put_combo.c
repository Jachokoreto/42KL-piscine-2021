#include <unistd.h>

int	put_combo(int pointer[])


