#include <unistd.h>

void	ft_putchar(char c);

void	rush(int target_x, int target_y)
{
	int	current_y;
	int	current_x;

	current_y = 1;
	current_x = 1;
	while (current_y <= target_y)
	{
		while (current_x <= target_x)
		{
			if ((current_y == 1 || current_y == target_y)
				 && (current_x == 1 || current_x == target_x))
				ft_putchar('o');
			else if ((current_y >= 1 && current_y <= target_y)
				      && (current_x == 1 || current_x == target_x))
				ft_putchar('|');
			else if ((current_y == 1 || current_y == target_y)
				      && (current_x >= 1 || current_x <= target_x))
				ft_putchar('-');
			else
				ft_putchar(' ');
			current_x++;
		}
		ft_putchar('\n');
		current_y++;
		current_x = 1;
	}
}
