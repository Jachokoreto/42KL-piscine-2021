void	rush(int x, int y);

int	main(void)
{
	rush(5, 5);
	return (0);
}
